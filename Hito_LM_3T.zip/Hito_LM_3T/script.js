// Realizar petición fetch para obtener la lista de provincias
fetch('https://www.el-tiempo.net/api/json/v1/provincias')
  .then(response => response.json())
  .then(data => {
    const provincias = data.provincias;
    const provinciasList = document.getElementById('provincias');

    provincias.forEach(provincia => {
      const li = document.createElement('li');
      li.textContent = provincia.NOMBRE_PROVINCIA;
      li.classList.add('provincia');
      provinciasList.appendChild(li);
    });
  })
  .catch(error => {
    console.log('Error al obtener la lista de provincias:', error);
  });

// Realizar petición fetch para obtener la lista de municipios
fetch('https://www.el-tiempo.net/api/json/v1/municipios')
  .then(response => response.json())
  .then(data => {
    const municipios = data.municipios.slice(0, 10); // Mostrar solo los primeros 10 municipios
    const municipiosList = document.getElementById('municipios');

    municipios.forEach(municipio => {
      const li = document.createElement('li');
      li.textContent = municipio.NOMBRE;
      municipiosList.appendChild(li);
    });
  })
  .catch(error => {
    console.log('Error al obtener la lista de municipios:', error);
  });
